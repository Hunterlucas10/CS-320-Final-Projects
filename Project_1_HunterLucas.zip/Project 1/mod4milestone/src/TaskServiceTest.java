import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskServiceTest {

	@Test
	public void testAddTask() {
        TaskService taskService = new TaskService();
        taskService.addTask("task", "Test task", "This should be a test task.");
        Task task = taskService.getTask("task");
        assertNotNull(task);
        assertEquals("task", task.getTaskId());
        assertEquals("Test task", task.getName());
    }


    @Test
    public void testDeleteTask() {
        TaskService taskService = new TaskService();
        taskService.addTask("task1", "Test Task", "This should be a test task.");
        taskService.deleteTask("task1");
        assertNull(taskService.getTask("task1"));
    }
    
    
    @Test
    public void testAddDuplicateTask() {
        TaskService taskService = new TaskService();
        taskService.addTask("task1", "Test Task", "This should be a test task.");
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask("task1", "Another Task", "SHould be another description."));
    }


    @Test
    public void testUpdateTask() {
        TaskService taskService = new TaskService();
        taskService.addTask("task1", "Test Task", "This should be a test task.");
        taskService.updateTask("task1", "Updated Task", "Should be an updated description.");
        Task task = taskService.getTask("task1");
        assertEquals("Updated Task", task.getName());
        assertEquals("Should be an updated description.", task.getDescription());
    }


    @Test
    public void testUpdateTaskName() {
        TaskService taskService = new TaskService();
        taskService.addTask("task1", "Test Task", "Hopefully its a task.");
        taskService.updateTask("task1", "Updated name!", null);
        Task task = taskService.getTask("task1");
        assertEquals("Updated name!", task.getName());
        assertEquals("Hopefully its a task.", task.getDescription());
    }

}
