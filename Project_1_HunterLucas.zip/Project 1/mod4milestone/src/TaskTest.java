import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskTest {

	@Test
	public void testTaskCreation() {
        Task task = new Task("task", "Test Task", "Just testing this.");
        assertEquals("task", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("Just testing this.", task.getDescription());
    }

    @Test
    public void testTaskValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Task("probablytoolong", "Test Name", "Just Testing this."));
        assertThrows(IllegalArgumentException.class, () -> new Task("task2", "Probably too long of a name", "Just testing this."));
        assertThrows(IllegalArgumentException.class, () -> new Task("task3", "Test Name", "A very long description that exceeds fifty characters for sure, at least I hope."));
    }

    @Test
    public void testSetters() {
        Task task = new Task("task4", "Test Task", "Test Description");
        task.setName("Updated Task");
        task.setDescription("Updated Description");
        assertEquals("Updated Task", task.getName());
        assertEquals("Updated Description", task.getDescription());
    }

    @Test
    public void testInvalidSetters() {
        Task task = new Task("task5", "Test Task", "Test Description");
        assertThrows(IllegalArgumentException.class, () -> task.setName("Probably too long of a name"));
        assertThrows(IllegalArgumentException.class, () -> task.setDescription("I really do not know what else to type here except this is getting too long."));
    }
}