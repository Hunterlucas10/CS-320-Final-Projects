public class Task {
    private final String taskId;  // cannot be updated!
    private String name;          // updatable
    private String description;   // updatable

    
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("TaskId needs to be less than or equal to ten characters and not null");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Name must be less than or equal to 20 charactersand not null.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must be less than or equal to 50 characters and not null.");
        }
        
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // getters
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // setters
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Name cannot be null and must be less than or equal to 20 characters.");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description cannot be null and must be less than or equal to 50 characters.");
        }
        this.description = description;
    }
}