import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks = new HashMap<>(); // storage for tasks

    // adding a task
    public void addTask(String taskId, String name, String description) {
        if (tasks.containsKey(taskId)) { // throws error for existing taskID
            throw new IllegalArgumentException("Task ID already exists.");
        }
        Task task = new Task(taskId, name, description); // else adds task
        tasks.put(taskId, task);
    }

    // deleting a task
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) { // throws error for no taskId
            throw new IllegalArgumentException("Task ID not found.");
        }
        tasks.remove(taskId); // else removes task
    }

    // updating fields of task
    public void updateTask(String taskId, String name, String description) {
        Task task = tasks.get(taskId);
        if (task == null) { // throws error for no taskId
            throw new IllegalArgumentException("Task ID not found.");
        }
        if (name != null) task.setName(name);
        if (description != null) task.setDescription(description);
    }

    // method to returns a task for testing
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}