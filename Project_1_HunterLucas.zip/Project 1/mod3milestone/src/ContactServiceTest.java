import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("1", "Hunter", "Lucas", "1234567890", "123 Main St");
        service.addContact(contact);
    }

    @Test
    public void testAddDuplicateContacts() {
        Contact contact1 = new Contact("1", "Hunter", "Lucas", "1234567890", "123 Main St");
        Contact contact2 = new Contact("1", "Justin", "Thomas", "0987654321", "456 Main St");

        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("2", "Payton", "Johnson", "9999999999", "789 Prospect St");
        service.addContact(contact);
        service.deleteContact("2");

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("2");
        });
    }

    @Test
    public void testUpdateFirstName() {
        Contact contact = new Contact("3", "Miles", "Bridges", "1111111110", "321 Franklin St");
        service.addContact(contact);
        service.updateFirstName("3", "Mark");

        assertEquals("Mark", contact.getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        Contact contact = new Contact("4", "Abby", "West", "1111111110", "123 Main St");
        service.addContact(contact);
        service.updateLastName("4", "Smith");

        assertEquals("Smith", contact.getLastName());
    }

    @Test
    public void testUpdatePhone() {
        Contact contact = new Contact("5", "Viktor", "Hovland", "1111111110", "1045 106th Ave");
        service.addContact(contact);
        service.updatePhone("5", "0000000001");

        assertEquals("0000000001", contact.getPhone());
    }

    @Test
    public void testUpdateAddress() {
        Contact contact = new Contact("6", "Rick", "Stilt", "1111111110", "4090 Cedar St");
        service.addContact(contact);
        service.updateAddress("6", "1200 Firefly Ln");

        assertEquals("1200 Firefly Ln", contact.getAddress());
    }

    @Test
    public void testInvalidIdUpdate() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("765", "Peeta");
        });
    }
}