import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("1", "Zakary", "Alan", "1234567890", "123 Main St");
        assertEquals("1", contact.getContactId());
        assertEquals("Zakary", contact.getFirstName());
        assertEquals("Alan", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    public void testContactIdLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Hunter", "Lucas", "1234567890", "123 Main St");
        });
    }

    @Test
    public void testNullFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("2", null, "Doe", "1234567890", "123 Main St");
        });
    }

    @Test
    public void testLongFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("3", "Thisnameiswaytoolong", "Doe", "1234567890", "123 Main St");
        });
    }

    @Test
    public void testPhoneNumber() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("4", "Hunter", "Doe", "12345", "123 Main St");
        });
    }

    @Test
    public void testNullAddress() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("5", "Hunter", "Doe", "1234567890", null);
        });
    }

    @Test
    public void testSetters() {
        Contact contact = new Contact("6", "Hunter", "Lucas", "1234567890", "123 Main St");
        contact.setFirstName("Quinn");
        contact.setLastName("Stark");
        contact.setPhone("0987654321");
        contact.setAddress("321 Main St");

        assertEquals("Quinn", contact.getFirstName());
        assertEquals("Stark", contact.getLastName());
        assertEquals("0987654321", contact.getPhone());
        assertEquals("321 Main St", contact.getAddress());
    }
}