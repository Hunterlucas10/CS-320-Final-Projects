import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

// building tests for appointment class

public class AppointmentTest {

    @Test
    public void testAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appt = new Appointment("HL1028", futureDate, "Test Appointment");
        assertEquals("HL1028", appt.getAppointmentId());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Test Appointment", appt.getDescription());
    }

    @Test
    public void testNullId() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Appointment");
        });
    }

    @Test
    public void testLongId() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("hl304ffali39gg", futureDate, "Appointment");
        });
    }

    @Test
    public void testPastDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        Date pastDate = calendar.getTime();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("HL1028", pastDate, "Past appointment");
        });
    }

    @Test
    public void testNullDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("HL1028", futureDate, null);
        });
    }

    @Test
    public void testLongDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        String longDesc = "I really hope that this sentence is longer than fifty characters! I think it is now.";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("HL1028", futureDate, longDesc);
        });
    }
}