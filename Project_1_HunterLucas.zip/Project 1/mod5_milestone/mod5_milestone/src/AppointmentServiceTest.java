import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

// building tests for appointment service

public class AppointmentServiceTest {
    private AppointmentService service;
    private Appointment appointment;

    @BeforeEach
    public void setup() {
        service = new AppointmentService();
        appointment = new Appointment("HL1028", new Date(System.currentTimeMillis() + 100000), "New appointment");
    }

    @Test
    public void testAddAppointment() {
        service.addAppointment(appointment);
        assertEquals(appointment, service.getAppointment("HL1028"));
    }

    @Test
    public void testAddDuplicate() {
        service.addAppointment(appointment);
        Appointment duplicate = new Appointment("HL1028", new Date(System.currentTimeMillis() + 200000), "New Appointment");
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(duplicate);
        });
    }

    @Test
    public void testDeleteAppointment() {
        service.addAppointment(appointment);
        service.deleteAppointment("HL1028");
        assertNull(service.getAppointment("HL1028"));
    }

    @Test
    public void testDeleteNonExistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("NON_EXISTENT");
        });
    }
}